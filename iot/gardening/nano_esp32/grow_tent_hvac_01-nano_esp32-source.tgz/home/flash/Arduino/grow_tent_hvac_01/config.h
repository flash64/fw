#ifndef __CONFIG_H__
#define __CONFIG_H__

#define BROKER_ADDR         IPAddress(100,66,128,225)

const uint8_t mac[] = {0x74, 0x4D, 0xBD, 0xA0, 0xC5, 0x5C};
#define DEVICE_ID "a0c55c"
#define DEVICE_NAME "Grow Tent HVAC - " DEVICE_ID

const uint64_t OTA_VERSION = 116;
#define SOFTWARE_VERSION "1.2.116"
const char OTA_VERSION_LOCATION[] = "https://firmware.jpod.cc/iot/gardening/nano_esp32/grow_tent_hvac_01-nano_esp32.ota.version";
const char OTA_FILE_LOCATION[] = "https://firmware.jpod.cc/iot/gardening/nano_esp32/grow_tent_hvac_01-nano_esp32.ota";

const bool DEBUG = false;

#define NUM_FANS                1
#define NUM_SENSORS_DHT         1
#define NUM_SENSORS_MOISTURE    1

#define PIN_FAN_00              A7
#define DHT_SENSOR_TYPE         DHT_TYPE_22
#define PIN_SENSOR_DHT_00       2
#define PIN_SENSOR_DHT_01       3
#define PIN_SENSOR_MOISTURE_00  A0
#define PIN_SENSOR_MOISTURE_01  A1
#define PIN_SENSOR_MOISTURE_02  A2
#define PIN_SENSOR_MOISTURE_03  A3
#define PIN_SENSOR_MOISTURE_04  A4
#define PIN_SENSOR_MOISTURE_05  A5
#define PIN_SENSOR_MOISTURE_06  A6


/*
Temperature:

Growth stage          Daytime temp.	    Nighttime temp.	  Humidity
Seedling stage	      68-77 F°/20-25 C°	59-68 F°/15-20 C°	65-70%
Vegetative stage	    71-83 F°/22-28 C°	64-74 F°/18-23 C°	40-70%
Flowering stage	      68-79 F°/20-26 C°	64-74 F°/18-23 C°	35-45%
Late flowering stage	65-75 F°/18-24 C°	60-65 F°/15-18 C°	30-40%

Humidity:

Growth Week 1	    60%	70%
Growth Week 2	    60%	70%
Flowering Week 1	55%	65%
Flowering Week 2	50%	60%
Flowering Week 3	50%	55%
Flowering Week 4	50%	50%
Flowering Week 5	50%	50%
Flowering Week 6	45%	45%
Flowering Week 7	45%	45%
Flowering Week 8	40%	40%
Flowering Week 9	40%	40%
*/

/*
#define REF_TEMP_SEEDLING         toPercent(22.5, values_low[0], values_high[0])
#define REF_TEMP_VEGETATIVE       toPercent(25, values_low[0], values_high[0])
#define REF_TEMP_FLOWER_EARLY     toPercent(23, values_low[0], values_high[0])
#define REF_TEMP_FLOWER_LATE      toPercent(21, values_low[0], values_high[0])

#define REF_HUMIDITY_SEEDLING     toPercent(67.5, values_low[1], values_high[1])
#define REF_HUMIDITY_VEGETATIVE   toPercent(55, values_low[1], values_high[1])
#define REF_HUMIDITY_FLOWER_EARLY toPercent(40, values_low[1], values_high[1])
#define REF_HUMIDITY_FLOWER_LATE  toPercent(35, values_low[1], values_high[1])
*/

/*
#define REF_TEMP_SEEDLING 22
#define REF_TEMP_VEGETATIVE 25
#define REF_TEMP_FLOWER_EARLY 23
#define REF_TEMP_FLOWER_LATE 21

#define REF_HUMIDITY_SEEDLING 67
#define REF_HUMIDITY_VEGETATIVE 55
#define REF_HUMIDITY_FLOWER_EARLY 40
#define REF_HUMIDITY_FLOWER_LATE 35
*/

/*
// 100% is perfect (ie the middle between high and low).
// so: low = low end of range, high = low+range/2
const uint16_t values_low[] =  {20, 40, 0, 0, 0, 0, 0, 0};
const uint16_t values_high[] = {23, 55, 0, 0, 0, 0, 0, 0};
*/

/* Using AREF = 3.3V
 * const int valAir / values_low = 3000;  
 * const int valWater / values_high = 1500;
 */
//const uint16_t moisture_values_low[] = {3150};
//const uint16_t moisture_values_high[] = {1300};
const uint16_t moisture_values_low[] = {3370};
const uint16_t moisture_values_high[] = {1730};

/*
// 50% is perfect (ie the middle between high and low).
// so: low = low end of range, high = high end of range
const uint16_t values_dht_temperature_low[] = { 20, 40, 0, 0, 0, 0, 0, 0 };
const uint16_t values_dht_temperature_high[] = { 26, 70, 0, 0, 0, 0, 0, 0 };

const uint16_t values_dht_low[] = { 20, 40, 0, 0, 0, 0, 0, 0 };
const uint16_t values_dht_high[] = { 26, 70, 0, 0, 0, 0, 0, 0 };
*/

//#define VALUE_LOW_ADJ (2.0/6.0)

/*
 SimpleKalmanFilter(e_mea, e_est, q);
 e_mea: Measurement Uncertainty
 e_est: Estimation Uncertainty
 q: Process Noise

 SimpleKalmanFilter simpleKalmanFilter(2, 2, 0.01);
*/
#define KF_DHT_E_MEA 1
#define KF_DHT_E_EST  KF_DHT_E_MEA
#define KF_DHT_Q 0.1

#define KF_MOISTURE_E_MEA 96
#define KF_MOISTURE_E_EST  KF_MOISTURE_E_MEA
#define KF_MOISTURE_Q 0.005

#include "defaults_grow_tent_hvac.h"
#endif /* __CONFIG_H__ */