#include "grow_tent_hvac.h"
#include <DHT_Async.h>
#if NUM_FANS > 0
#include <PID_v1.h>

HANumber target_humidity(DEVICE_ID"-target-humidity", HASensorNumber::PrecisionP0);
double target_humidity_value = 60;
HASwitch switch_auto_fan(DEVICE_ID"-auto-fan");
bool auto_fan_enabled = true;
double humidity_input = 60;
double fan_pwm_output;
PID fan_pid(&humidity_input, &fan_pwm_output, &target_humidity_value, 10, 0.2, 1, REVERSE);
HASensorNumber sensors_fan_pid_output = HASensorNumber(DEVICE_ID"-fan-pid-output-00", HASensorNumber::PrecisionP0);
#endif /* #if NUM_FANS > 0 */

DHT_Async dht_sensors[NUM_SENSORS_DHT] = {
    DHT_Async{SENSOR_DHT_pins[0], DHT_SENSOR_TYPE}
  };
/*
HASensorNumber sensors_dht_percent[NUM_SENSORS_DHT*2] = {
    HASensorNumber{DEVICE_ID"-temperature-00", HASensorNumber::PrecisionP1},
    HASensorNumber{DEVICE_ID"-humidity-00", HASensorNumber::PrecisionP1}
  };
*/
HASensorNumber sensors_dht_filtered[NUM_SENSORS_DHT*2] = {
    HASensorNumber{DEVICE_ID"-temperature-00", HASensorNumber::PrecisionP1},
    HASensorNumber{DEVICE_ID"-humidity-00", HASensorNumber::PrecisionP1}
  };
HASensorNumber sensors_dht_raw[NUM_SENSORS_DHT*2] = {
    HASensorNumber{DEVICE_ID"-temperature-00_raw", HASensorNumber::PrecisionP1},
    HASensorNumber{DEVICE_ID"-humidity-00_raw", HASensorNumber::PrecisionP1}
  };

/*
 SimpleKalmanFilter(e_mea, e_est, q);
 e_mea: Measurement Uncertainty
 e_est: Estimation Uncertainty
 q: Process Noise

 SimpleKalmanFilter simpleKalmanFilter(2, 2, 0.01);
*/
SimpleKalmanFilter kalman_filter_dht[NUM_SENSORS_DHT*2] = {
    SimpleKalmanFilter{KF_DHT_E_MEA, KF_DHT_E_EST, KF_DHT_Q},
    SimpleKalmanFilter{KF_DHT_E_MEA, KF_DHT_E_EST, KF_DHT_Q}
  };

//float_t sensor_values_dht_percent[NUM_SENSORS_DHT*2];
float_t sensor_values_dht_filtered[NUM_SENSORS_DHT*2];
float_t sensor_values_dht_raw[NUM_SENSORS_DHT*2];

#if NUM_FANS > 0
HAFan fans[NUM_FANS] = {
    HAFan{DEVICE_ID"-fan-00", HAFan::SpeedsFeature}
  };
HASensorNumber sensors_fan_speed[NUM_FANS] = {
    HASensorNumber{DEVICE_ID"-fan-speed-00", HASensorNumber::PrecisionP0}
  };

uint8_t  fan_states[NUM_FANS];
uint16_t fan_speeds[NUM_FANS];


void onTargetHumidityCommand(HANumeric number, HANumber* sender) {
  /*
  for (uint8_t i = 0; i < NUM_FANS; i++) {
    if (sender == &(fans[i])) {
      if (DEBUG) {
        Serial.print("[onStateCommand] setting fan ");
        Serial.print(i);
        Serial.print("to state ");
        Serial.println(state);
      }
      fan_states[i] = state;
      if (state == 0) {
        analogWrite(FAN_pins[i], 0);
      }
      else if (state == 1) {
        analogWrite(FAN_pins[i], fan_speeds[i]);
      }
    }
  }
  */
  if (!number.isSet()) {
    target_humidity_value = 60;
  } else {
    target_humidity_value = number.toUInt8();
  }

  sender->setState(number);
}


void on_switch_auto_fan_command(bool state, HASwitch* sender) {
  auto_fan_enabled = state;

  sender->setState(state);
}
#endif /* #if NUM_FANS > 0 */

# if NUM_SENSORS_MOISTURE > 0
HASensorNumber sensors_moisture_percent[NUM_SENSORS_MOISTURE] = {
    HASensorNumber{DEVICE_ID"-soil-moisture-00", HASensorNumber::PrecisionP1}
  };
HASensorNumber sensors_moisture_filtered[NUM_SENSORS_MOISTURE] = {
    HASensorNumber{DEVICE_ID"-soil-moisture-00-filtered", HASensorNumber::PrecisionP1}
  };
HASensorNumber sensors_moisture_raw[NUM_SENSORS_MOISTURE] = {
    HASensorNumber{DEVICE_ID"-soil-moisture-00-raw", HASensorNumber::PrecisionP1}
  };

uint16_t sensor_values_moisture_raw[NUM_SENSORS_MOISTURE];
float_t sensor_values_moisture_filtered[NUM_SENSORS_MOISTURE];
float_t sensor_values_moisture_percent[NUM_SENSORS_MOISTURE];
float_t sensor_values_moisture_percent_filtered[NUM_SENSORS_MOISTURE];

SimpleKalmanFilter kalman_filter_moisture[NUM_SENSORS_MOISTURE] = {
    SimpleKalmanFilter{KF_MOISTURE_E_MEA, KF_MOISTURE_E_EST, KF_MOISTURE_Q}
  };
#endif /* #if NUM_SENSORS_MOISTURE */

void setup() {
  setup_common();

  uint8_t i = 0;
#if NUM_FANS > 0
  fans[i].setIcon("mdi:fan");
  fans[i].setName("Grow Tent Fan 00");
  fans[i].onStateCommand(onStateCommand);
  fans[i].onSpeedCommand(onSpeedCommand);
  fans[i].setSpeedRangeMin(1);
  fans[i].setSpeedRangeMax(100);
  fans[i].setSpeed(0);
  fan_speeds[i] = 0;
  fan_states[i] = 0;
  sensors_fan_speed[i].setIcon("pap:fan_speed_button");
  sensors_fan_speed[i].setName("Grow Tent Fan Speed 00");
  sensors_fan_speed[i].setUnitOfMeasurement("%");
#endif /* #if NUM_FANS > 0 */

# if NUM_SENSORS_MOISTURE > 0
  i = 0;
  sensors_moisture_percent[i].setIcon("mdi:flower-tulip-outline");
  sensors_moisture_percent[i].setName("Soil Moisture");
  sensors_moisture_percent[i].setUnitOfMeasurement("%");

  sensors_moisture_filtered[i].setIcon("mdi:flower-tulip-outline");
  sensors_moisture_filtered[i].setName("Soil Moisture Filtered");
  sensors_moisture_filtered[i].setUnitOfMeasurement("filtered raw");

  sensors_moisture_raw[i].setIcon("mdi:flower-tulip-outline");
  sensors_moisture_raw[i].setName("Soil Moisture Raw");
  sensors_moisture_raw[i].setUnitOfMeasurement("raw");
#endif /* #if NUM_SENSORS_MOISTURE > 0 */

  i = 0;
  /*
  sensors_percent_float[i].setIcon("mdi:thermometer");
  sensors_percent_float[i].setName("Temperature Percentage");
  sensors_percent_float[i].setUnitOfMeasurement("%");
  sensor_values_percent_float[i] = 100.0;
  */

  sensors_dht_filtered[i].setIcon("mdi:thermometer");
  sensors_dht_filtered[i].setName("Grow Tent Temperature 00");
  sensors_dht_filtered[i].setUnitOfMeasurement("°C");

  sensors_dht_raw[i].setIcon("mdi:thermometer");
  sensors_dht_raw[i].setName("Grow Tent Temperature Raw 00");
  sensors_dht_raw[i].setUnitOfMeasurement("°C");

  i = 1;
  /*
  sensors_percent_float[i].setIcon("mdi:water-percent");
  sensors_percent_float[i].setName("Humidity Percentage");
  sensors_percent_float[i].setUnitOfMeasurement("%");
  sensor_values_percent_float[i] = 100.0;
  */

  sensors_dht_filtered[i].setIcon("mdi:water-percent");
  sensors_dht_filtered[i].setName("Grow Tent Humidity 00");
  sensors_dht_filtered[i].setUnitOfMeasurement("%");

  sensors_dht_raw[i].setIcon("mdi:water-percent");
  sensors_dht_raw[i].setName("Grow Tent Humidity Raw 00");
  sensors_dht_raw[i].setUnitOfMeasurement("%");

#if NUM_FANS > 0
  target_humidity.setIcon("mdi:air-humidifier");
  target_humidity.setName("Grow Tent Target Humidity");
  target_humidity.setUnitOfMeasurement("%");
  target_humidity.setMin(5);
  target_humidity.setMax(95);
  target_humidity.setMode(HANumber::ModeSlider);
  target_humidity.setStep(1);
  target_humidity.onCommand(onTargetHumidityCommand);
  target_humidity.setState((uint32_t)target_humidity_value);

  switch_auto_fan.setIcon("mdi:fan-auto");
  switch_auto_fan.setName("Grow Tent Auto Fan");
  switch_auto_fan.onCommand(on_switch_auto_fan_command);

  fan_pid.SetMode(AUTOMATIC);
  fan_pid.SetOutputLimits(0, PWM_MAX_DUTY_CYCLE);
  sensors_fan_pid_output.setIcon("mdi:car-cruise-control");
  sensors_fan_pid_output.setName("Grow Tent Fan PID Output");
  sensors_fan_pid_output.setUnitOfMeasurement("pwm");
#endif /* #if NUM_FANS > 0 */

  setup_common_end();
}


void timer_100hz_cb(void) {
#if NUM_FANS > 0
  if (auto_fan_enabled) {
    fan_pid.Compute();
  } else {
    fan_pwm_output = 0;
  }
#endif /* #if NUM_FANS > 0 */

# if NUM_SENSORS_MOISTURE > 0
  for (uint8_t i = 0; i < NUM_SENSORS_MOISTURE; i++) {
    sensor_values_moisture_raw[i] = (analogRead(sensor_moisture_pins[i]) + analogRead(sensor_moisture_pins[i]) + analogRead(sensor_moisture_pins[i])) / 3;
    sensor_values_moisture_filtered[i] = kalman_filter_moisture[i].updateEstimate(sensor_values_moisture_raw[i]);
  }
#endif /* #if NUM_SENSORS_MOISTURE > 0 */
}

void timer_10hz_cb(void) {
}

void timer_5hz_cb(void) {
}

void timer_1hz_cb(void) {
}

void timer_0_5hz_cb(void) {
  float temperature;
  float humidity;

  for (uint8_t i=0; i < NUM_SENSORS_DHT; i++) {
    if (get_temp_humidity(i, &temperature, &humidity)) {
      sensor_values_dht_raw[i] = temperature;
      sensor_values_dht_filtered[i] = kalman_filter_dht[i].updateEstimate(sensor_values_dht_raw[i]);

      sensor_values_dht_raw[i+1] = humidity;
      sensor_values_dht_filtered[i+1] = kalman_filter_dht[i+1].updateEstimate(sensor_values_dht_raw[i+1]);
    }
  }
}

void timer_0_25hz_cb(void) {
}

void timer_0_1hz_cb(void) {
}

void loop() {
  loop_common();
}
